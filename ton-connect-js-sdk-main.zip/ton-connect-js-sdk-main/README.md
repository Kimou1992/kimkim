https://ton-connect.github.io/sdk/modules/_tonconnect_ui.html
https://core.telegram.org/bots/webapps#initializing-mini-apps